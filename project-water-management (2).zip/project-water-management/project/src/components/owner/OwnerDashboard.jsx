import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { UsersIcon, PlusIcon, UserIcon, IndianRupeeIcon, ChevronDownIcon, ChevronUpIcon, DropletIcon } from 'lucide-react';
import Navbar from '../common/Navbar';
import { useAuth } from '../../context/AuthContext';
import {getAllCustomers, getCustomerJarStats, updateJarTransaction} from '../../data/mockData';

const OwnerDashboard = () => {
  const { currentUser } = useAuth();
  
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedCustomer, setExpandedCustomer] = useState(null);
  const [jarPrice] = useState(20); // Fixed price per jar

  useEffect(() => {
    const fetchCustomers = async () => {
      const allCustomers = await getAllCustomers();
      
      const customersWithStats = await Promise.all(
        allCustomers.map(async (customer) => {
          const stats = await getCustomerJarStats(customer.id);
          return {
            ...customer,
            currentJars: stats.currentJars,
            deliveredJars: stats.deliveredJars || 0,
            receivedJars: stats.receivedJars || 0,
            totalDue: stats.totalDue || 0
          };
        })
      );
      
      setCustomers(customersWithStats);
      setLoading(false);
    };
    
    fetchCustomers();
  }, []);
  
  const getTotalStats = () => {
    return customers.reduce(
      (acc, customer) => {
        return {
          totalCustomers: acc.totalCustomers + 1,
          totalJars: acc.totalJars + customer.currentJars,
          totalDue: acc.totalDue + customer.totalDue
        };
      },
      { totalCustomers: 0, totalJars: 0, totalDue: 0 }
    );
  };
  
  const toggleCustomerExpand = (customerId) => {
    setExpandedCustomer(expandedCustomer === customerId ? null : customerId);
  };

  const handleJarChange = async (customerId, type, value) => {
    const updatedCustomers = customers.map(customer => {
      if (customer.id === customerId) {
        const newDelivered = type === 'delivered' ? Math.max(0, value) : customer.deliveredJars;
        const newReceived = type === 'received' ? Math.max(0, value) : customer.receivedJars;
        
        const currentJars = newDelivered - newReceived;
        const totalDue = currentJars * jarPrice;
        
        return {
          ...customer,
          deliveredJars: newDelivered,
          receivedJars: newReceived,
          currentJars,
          totalDue
        };
      }
      return customer;
    });
    
    setCustomers(updatedCustomers);
    
    // Update in mock data (would be API call in real app)
    const customerToUpdate = updatedCustomers.find(c => c.id === customerId);
    if (customerToUpdate) {
      await updateCustomerJarStats(customerId, {
        deliveredJars: customerToUpdate.deliveredJars,
        receivedJars: customerToUpdate.receivedJars,
        currentJars: customerToUpdate.currentJars,
        totalDue: customerToUpdate.totalDue
      });
    }
  };

  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (customer.contactNumber && customer.contactNumber.includes(searchTerm))
  );
  
  if (!currentUser) return null;
  
  const stats = getTotalStats();
  
  return (
    <div className="dashboard-container">
      <Navbar />
      
      <div className="container mt-4">
        <div className="d-flex justify-between align-center mb-4">
          <h1 className="dashboard-title">Owner Dashboard</h1>
          <Link to="/add-customer" className="btn btn-primary">
            <PlusIcon size={16} className="mr-1" />
            Add Customer
          </Link>
        </div>
        
        {/* Stats Cards */}
        <div className="row mb-4">
          <div className="col-md-4">
            <div className="stats-card">
              <div className="stats-icon bg-blue-100">
                <UsersIcon size={28} className="text-blue-600" />
              </div>
              <div className="stats-content">
                <h4 className="stats-label">Total Customers</h4>
                <h2 className="stats-value text-blue-600">{stats.totalCustomers}</h2>
              </div>
            </div>
          </div>
          
          <div className="col-md-4">
            <div className="stats-card">
              <div className="stats-icon bg-green-100">
                <DropletIcon size={28} className="text-green-600" />
              </div>
              <div className="stats-content">
                <h4 className="stats-label">Active Jars</h4>
                <h2 className="stats-value text-green-600">{stats.totalJars}</h2>
              </div>
            </div>
          </div>
          
          <div className="col-md-4">
            <div className="stats-card">
              <div className="stats-icon bg-amber-100">
                <IndianRupeeIcon size={28} className="text-amber-600" />
              </div>
              <div className="stats-content">
                <h4 className="stats-label">Total Outstanding</h4>
                <h2 className="stats-value text-amber-600">₹{stats.totalDue.toFixed(2)}</h2>
              </div>
            </div>
          </div>
        </div>
        
        {/* Customer Table */}
        <div className="card">
          <div className="card-header d-flex justify-between align-center">
            <h3 className="mb-0">Customer Management</h3>
            <div className="search-box">
              <input
                type="text"
                className="form-control"
                placeholder="Search customers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="card-body">
            {loading ? (
              <div className="loading-spinner">Loading customers...</div>
            ) : filteredCustomers.length === 0 ? (
              <div className="empty-state">No customers found.</div>
            ) : (
              <div className="table-responsive">
                <table className="customer-table">
                  <thead>
                    <tr>
                      <th>Customer</th>
                      <th>Contact</th>
                      <th>Jar Status</th>
                      <th>Amount Due</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredCustomers.map(customer => (
                      <>
                        <tr key={customer.id} className="customer-row">
                          <td>
                            <div className="customer-info">
                              <div className="customer-avatar">
                                <UserIcon size={16} className="text-primary" />
                              </div>
                              <div>
                                <p className="customer-name">{customer.name}</p>
                                <p className="customer-email">{customer.email}</p>
                              </div>
                            </div>
                          </td>
                          <td>{customer.contactNumber || 'N/A'}</td>
                          <td>
                            <div className="jar-status">
                              <span className={`jar-count ${customer.currentJars > 0 ? 'active' : ''}`}>
                                {customer.currentJars} Jars
                              </span>
                              <button 
                                className="toggle-details"
                                onClick={() => toggleCustomerExpand(customer.id)}
                              >
                                {expandedCustomer === customer.id ? (
                                  <ChevronUpIcon size={16} />
                                ) : (
                                  <ChevronDownIcon size={16} />
                                )}
                              </button>
                            </div>
                          </td>
                          <td className="amount-due">₹{customer.totalDue.toFixed(2)}</td>
                          <td>
                            <Link to={`/customer/${customer.id}`} className="btn btn-outline btn-sm">
                              Manage
                            </Link>
                          </td>
                        </tr>
                        
                        {expandedCustomer === customer.id && (
                          <tr className="jar-details-row">
                            <td colSpan="5">
                              <div className="jar-details">
                                <div className="jar-control">
                                  <label>Delivered Jars:</label>
                                  <div className="jar-counter">
                                    <button 
                                      className="counter-btn"
                                      onClick={() => handleJarChange(customer.id, 'delivered', customer.deliveredJars - 1)}
                                    >
                                      -
                                    </button>
                                    <span className="jar-count-value">{customer.deliveredJars}</span>
                                    <button 
                                      className="counter-btn"
                                      onClick={() => handleJarChange(customer.id, 'delivered', customer.deliveredJars + 1)}
                                    >
                                      +
                                    </button>
                                  </div>
                                </div>
                                
                                <div className="jar-control">
                                  <label>Received Jars:</label>
                                  <div className="jar-counter">
                                    <button 
                                      className="counter-btn"
                                      onClick={() => handleJarChange(customer.id, 'received', customer.receivedJars - 1)}
                                    >
                                      -
                                    </button>
                                    <span className="jar-count-value">{customer.receivedJars}</span>
                                    <button 
                                      className="counter-btn"
                                      onClick={() => handleJarChange(customer.id, 'received', customer.receivedJars + 1)}
                                    >
                                      +
                                    </button>
                                  </div>
                                </div>
                                
                                <div className="jar-summary">
                                  <div className="summary-item">
                                    <span>Current Jars:</span>
                                    <span className="summary-value">{customer.currentJars}</span>
                                  </div>
                                  <div className="summary-item">
                                    <span>Price per Jar:</span>
                                    <span className="summary-value">₹{jarPrice}</span>
                                  </div>
                                  <div className="summary-item total">
                                    <span>Total Amount:</span>
                                    <span className="summary-value">₹{customer.totalDue.toFixed(2)}</span>
                                  </div>
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <style jsx>{`
        .dashboard-container {
          background-color: #f8fafc;
          min-height: 100vh;
        }
        
        .container {
          padding: 0 1.5rem;
          max-width: 1200px;
          margin: 0 auto;
        }
        
        .dashboard-title {
          font-size: 1.75rem;
          font-weight: 600;
          color: #1e293b;
        }
        
        .stats-card {
          background: white;
          border-radius: 0.5rem;
          padding: 1.25rem;
          display: flex;
          align-items: center;
          box-shadow: 0 1px 3px rgba(0,0,0,0.1);
          height: 100%;
        }
        
        .stats-icon {
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          width: 60px;
          height: 60px;
          margin-right: 1rem;
        }
        
        .stats-content {
          flex: 1;
        }
        
        .stats-label {
          font-size: 0.875rem;
          color: #64748b;
          margin-bottom: 0.25rem;
          font-weight: 500;
        }
        
        .stats-value {
          font-size: 1.5rem;
          font-weight: 600;
          margin: 0;
        }
        
        .card {
          background: white;
          border-radius: 0.5rem;
          box-shadow: 0 1px 3px rgba(0,0,0,0.1);
          margin-bottom: 2rem;
        }
        
        .card-header {
          padding: 1.25rem 1.5rem;
          border-bottom: 1px solid #e2e8f0;
        }
        
        .card-body {
          padding: 1.5rem;
        }
        
        .search-box {
          width: 300px;
        }
        
        .customer-table {
          width: 100%;
          border-collapse: collapse;
        }
        
        .customer-table th {
          background-color: #f1f5f9;
          padding: 0.75rem 1rem;
          text-align: left;
          font-weight: 600;
          color: #475569;
          font-size: 0.875rem;
        }
        
        .customer-table td {
          padding: 1rem;
          border-bottom: 1px solid #e2e8f0;
          vertical-align: middle;
        }
        
        .customer-row:hover {
          background-color: #f8fafc;
        }
        
        .customer-info {
          display: flex;
          align-items: center;
        }
        
        .customer-avatar {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          background-color: #e0f2fe;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-right: 0.75rem;
        }
        
        .customer-name {
          font-weight: 500;
          margin-bottom: 0.25rem;
          color: #1e293b;
        }
        
        .customer-email {
          font-size: 0.75rem;
          color: #64748b;
          margin: 0;
        }
        
        .jar-status {
          display: flex;
          align-items: center;
        }
        
        .jar-count {
          padding: 0.25rem 0.5rem;
          border-radius: 0.25rem;
          background-color: #e2e8f0;
          color: #475569;
          font-size: 0.875rem;
        }
        
        .jar-count.active {
          background-color: #dcfce7;
          color: #166534;
        }
        
        .toggle-details {
          background: none;
          border: none;
          cursor: pointer;
          margin-left: 0.5rem;
          color: #64748b;
        }
        
        .amount-due {
          font-weight: 500;
          color: #b45309;
        }
        
        .jar-details-row {
          background-color: #f8fafc;
        }
        
        .jar-details {
          padding: 1rem;
          display: flex;
          flex-wrap: wrap;
          gap: 2rem;
        }
        
        .jar-control {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }
        
        .jar-control label {
          font-size: 0.875rem;
          color: #475569;
          font-weight: 500;
        }
        
        .jar-counter {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        
        .counter-btn {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          border: 1px solid #cbd5e1;
          background: white;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          color: #475569;
        }
        
        .counter-btn:hover {
          background-color: #f1f5f9;
        }
        
        .jar-count-value {
          min-width: 30px;
          text-align: center;
          font-weight: 500;
        }
        
        .jar-summary {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
          margin-left: auto;
          padding: 0.5rem 1rem;
          background-color: #f1f5f9;
          border-radius: 0.5rem;
        }
        
        .summary-item {
          display: flex;
          justify-content: space-between;
          min-width: 200px;
        }
        
        .summary-item.total {
          font-weight: 600;
          color: #1e293b;
          margin-top: 0.5rem;
          padding-top: 0.5rem;
          border-top: 1px solid #cbd5e1;
        }
        
        .summary-value {
          color: #1e293b;
        }
        
        .empty-state, .loading-spinner {
          padding: 2rem;
          text-align: center;
          color: #64748b;
        }
        
        @media (max-width: 768px) {
          .jar-details {
            flex-direction: column;
            gap: 1rem;
          }
          
          .jar-summary {
            margin-left: 0;
            width: 100%;
          }
        }
      `}</style>
    </div>
  );
};

export default OwnerDashboard;