import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  UserIcon, 
  ArrowLeftIcon, 
  DropletIcon, 
  PlusIcon, 
  MinusIcon, 
  RefreshCwIcon,
  CheckIcon,
  IndianRupeeIcon
} from 'lucide-react';
import Navbar from '../common/Navbar';
import { 
  getCustomerById, 
  getJarTransactions, 
  addJarTransaction,
  updateJarTransaction
} from '../../data/mockData';

const CustomerDetail = () => {
  const { id } = useParams();
  const [customer, setCustomer] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newTransaction, setNewTransaction] = useState({
    jarsTaken: 0,
    jarsReturned: 0,
    pricePerJar: 20.00, // Default price
  });
  
  useEffect(() => {
    const fetchData = async () => {
      if (id) {
        const customerData = await getCustomerById(id);
        const transactionsData = await getJarTransactions(id);
        
        setCustomer(customerData);
        setTransactions(transactionsData);
        setLoading(false);
      }
    };
    
    fetchData();
  }, [id]);
  
  const handleIncrementJarsTaken = () => {
    setNewTransaction(prev => ({
      ...prev,
      jarsTaken: prev.jarsTaken + 1
    }));
  };
  
  const handleDecrementJarsTaken = () => {
    if (newTransaction.jarsTaken > 0) {
      setNewTransaction(prev => ({
        ...prev,
        jarsTaken: prev.jarsTaken - 1
      }));
    }
  };
  
  const handleIncrementJarsReturned = () => {
    setNewTransaction(prev => ({
      ...prev,
      jarsReturned: prev.jarsReturned + 1
    }));
  };
  
  const handleDecrementJarsReturned = () => {
    if (newTransaction.jarsReturned > 0) {
      setNewTransaction(prev => ({
        ...prev,
        jarsReturned: prev.jarsReturned - 1
      }));
    }
  };
  
  const handlePriceChange = (e) => {
    const value = parseFloat(e.target.value);
    setNewTransaction(prev => ({
      ...prev,
      pricePerJar: isNaN(value) ? 0 : value
    }));
  };
  
  const handleAddTransaction = async () => {
    if (!id) return;
    
    // Only add transaction if jars taken or returned
    if (newTransaction.jarsTaken === 0 && newTransaction.jarsReturned === 0) {
      return;
    }
    
    const transaction = await addJarTransaction({
      customerId: id,
      jarsTaken: newTransaction.jarsTaken,
      jarsReturned: newTransaction.jarsReturned,
      pricePerJar: newTransaction.pricePerJar
    });
    
    // Update transactions list
    setTransactions(prev => [transaction, ...prev]);
    
    // Reset form
    setNewTransaction({
      jarsTaken: 0,
      jarsReturned: 0,
      pricePerJar: 2.00,
    });
  };
  
  const handleTogglePaid = async (transactionId, currentPaidStatus) => {
    const updatedTransaction = await updateJarTransaction(
      transactionId, 
      { isPaid: !currentPaidStatus }
    );
    
    // Update transactions list
    setTransactions(prev => 
      prev.map(transaction => 
        transaction.id === transactionId ? updatedTransaction : transaction
      )
    );
  };
  
  // Calculate stats
  const calculateTotalJars = () => {
    return transactions.reduce((total, transaction) => {
      return total + (transaction.jarsTaken - transaction.jarsReturned);
    }, 0);
  };
  
  const calculateTotalDue = () => {
    return transactions.reduce((total, transaction) => {
      const transactionAmount = transaction.jarsTaken * transaction.pricePerJar;
      return transaction.isPaid ? total : total + transactionAmount;
    }, 0);
  };
  
  if (loading) {
    return (
      <div>
        <Navbar />
        <div className="container mt-4">
          <p>Loading customer details...</p>
        </div>
      </div>
    );
  }
  
  if (!customer) {
    return (
      <div>
        <Navbar />
        <div className="container mt-4">
          <p>Customer not found.</p>
          <Link to="/owner-dashboard" className="btn btn-primary">
            <ArrowLeftIcon size={16} className="mr-1" />
            Back to Dashboard
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div>
      <Navbar />
      
      <div className="container mt-4">
        <Link to="/owner-dashboard" className="btn btn-outline mb-4">
          <ArrowLeftIcon size={16} className="mr-1" />
          Back to Dashboard
        </Link>
        
        <div className="card mb-4">
          <div className="card-body">
            <div className="row">
              <div className="col d-flex">
                <div className="d-flex align-center justify-center p-3 mr-3" 
                      style={{ 
                        background: 'var(--secondary-color)', 
                        borderRadius: '50%',
                        width: '64px',
                        height: '64px'
                      }}>
                  <UserIcon size={32} color="var(--primary-color)" />
                </div>
                <div>
                  <h2 className="mb-1">{customer.name}</h2>
                  <p className="mb-1">{customer.email}</p>
                  <p className="mb-0">{customer.contactNumber || 'No contact number'}</p>
                </div>
              </div>
              
              <div className="col d-flex align-center justify-between">
                <div className="text-center p-3">
                  <div className="d-flex align-center justify-center mb-2" 
                        style={{ 
                          margin: '0 auto',
                          background: 'var(--secondary-color)', 
                          borderRadius: '50%',
                          width: '48px',
                          height: '48px'
                        }}>
                    <DropletIcon size={24} color="var(--primary-color)" />
                  </div>
                  <h4 className="mb-1">Current Jars</h4>
                  <h3 className="text-primary">{calculateTotalJars()}</h3>
                </div>
                
                <div className="text-center p-3">
                  <div className="d-flex align-center justify-center mb-2" 
                        style={{ 
                          margin: '0 auto',
                          background: 'var(--secondary-color)', 
                          borderRadius: '50%',
                          width: '48px',
                          height: '48px'
                        }}>
                    <IndianRupeeIcon size={24} color="var(--primary-color)" />
                  </div>
                  <h4 className="mb-1">Total Due</h4>
                  <h3 className="text-primary">Rs{calculateTotalDue().toFixed(2)}</h3>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="card mb-4">
          <div className="card-header">
            <h3 className="mb-0">New Transaction</h3>
          </div>
          
          <div className="card-body">
            <div className="row">
              <div className="col">
                <div className="form-group">
                  <label className="form-label">Jars Delivered</label>
                  <div className="d-flex align-center">
                    <button 
                      className="btn btn-outline btn-icon mr-2"
                      onClick={handleDecrementJarsTaken}
                    >
                      <MinusIcon size={16} />
                    </button>
                    
                    <input
                      type="number"
                      className="form-control"
                      value={newTransaction.jarsTaken}
                      onChange={(e) => setNewTransaction(prev => ({
                        ...prev,
                        jarsTaken: parseInt(e.target.value) || 0
                      }))}
                      min="0"
                    />
                    
                    <button 
                      className="btn btn-outline btn-icon ml-2"
                      onClick={handleIncrementJarsTaken}
                    >
                      <PlusIcon size={16} />
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="col">
                <div className="form-group">
                  <label className="form-label">Jars Returned</label>
                  <div className="d-flex align-center">
                    <button 
                      className="btn btn-outline btn-icon mr-2"
                      onClick={handleDecrementJarsReturned}
                    >
                      <MinusIcon size={16} />
                    </button>
                    
                    <input
                      type="number"
                      className="form-control"
                      value={newTransaction.jarsReturned}
                      onChange={(e) => setNewTransaction(prev => ({
                        ...prev,
                        jarsReturned: parseInt(e.target.value) || 0
                      }))}
                      min="0"
                    />
                    
                    <button 
                      className="btn btn-outline btn-icon ml-2"
                      onClick={handleIncrementJarsReturned}
                    >
                      <PlusIcon size={16} />
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="col">
                <div className="form-group">
                  <label className="form-label">Price per Jar (Rs)</label>
                  <input
                    type="number"
                    className="form-control"
                    value={newTransaction.pricePerJar}
                    onChange={handlePriceChange}
                    min="0"
                    step="0.01"
                  />
                </div>
              </div>
            </div>
            
            <div className="d-flex justify-between align-center mt-3">
              <p className="mb-0">
                <strong>Total Amount:</strong> Rs{(newTransaction.jarsTaken * newTransaction.pricePerJar).toFixed(2)}
              </p>
              
              <button 
                className="btn btn-primary"
                onClick={handleAddTransaction}
                disabled={newTransaction.jarsTaken === 0 && newTransaction.jarsReturned === 0}
              >
                <RefreshCwIcon size={16} className="mr-1" />
                Add Transaction
              </button>
            </div>
          </div>
        </div>
        
        <div className="card">
          <div className="card-header">
            <h3 className="mb-0">Transaction History</h3>
          </div>
          
          <div className="card-body">
            {transactions.length === 0 ? (
              <p>No transactions found for this customer.</p>
            ) : (
              <div className="table-responsive">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Jars Delivered</th>
                      <th>Jars Returned</th>
                      <th>Price per Jar</th>
                      <th>Total</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map(transaction => (
                      <tr key={transaction.id}>
                        <td>{new Date(transaction.date).toLocaleDateString()}</td>
                        <td>{transaction.jarsTaken}</td>
                        <td>{transaction.jarsReturned}</td>
                        <td>Rs{transaction.pricePerJar.toFixed(2)}</td>
                        <td>Rs{(transaction.jarsTaken * transaction.pricePerJar).toFixed(2)}</td>
                        <td>
                          <span className={`p-1 ${transaction.isPaid ? 'text-success' : 'text-danger'}`}
                                style={{ 
                                  borderRadius: '4px',
                                  backgroundColor: transaction.isPaid ? 'rgba(46, 204, 113, 0.1)' : 'rgba(231, 76, 60, 0.1)',
                                  padding: '4px 8px'
                                }}>
                            {transaction.isPaid ? 'Paid' : 'Unpaid'}
                          </span>
                        </td>
                        <td>
                          <button 
                            className={`btn ${transaction.isPaid ? 'btn-outline' : 'btn-success'} btn-sm`}
                            onClick={() => handleTogglePaid(transaction.id, transaction.isPaid)}
                          >
                            {transaction.isPaid ? 'Mark Unpaid' : (
                              <>
                                <CheckIcon size={16} className="mr-1" />
                                Mark Paid
                              </>
                            )}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerDetail;
