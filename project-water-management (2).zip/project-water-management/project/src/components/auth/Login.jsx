import React from 'react';
import { useAuth } from '../../context/AuthContext'; // Assuming you have this
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const { logout, user } = useAuth(); // Assuming logout and user are available
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login'); // Go back to login after logout
  };

  return (
    <div className="auth-container">
      <div className="auth-card fade-in">
        <div className="auth-header">
          <div className="logo d-flex justify-center align-center mb-2">
            <h1 className="ml-1">Chippa Jal</h1>
          </div>
          <p>Welcome {user?.name || 'User'}!</p>
        </div>

        <div className="auth-body" style={{ textAlign: 'center' }}>
          <h2>Dashboard</h2>
          <p>You are logged in as <strong>{user?.email}</strong>.</p>

          <button 
            className="btn btn-primary w-100 mt-4"
            onClick={handleLogout}
          >
            Logout
          </button>
        </div>
      </div>
    </div>
  );
};

export default Home;
