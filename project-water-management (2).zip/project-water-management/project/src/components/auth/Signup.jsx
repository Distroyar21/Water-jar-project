import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { UserPlusIcon } from 'lucide-react'; // Import UserPlusIcon

const Signup = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'customer', // Default role
    contactNumber: '',
    address: ''
  });

  const [passwordError, setPasswordError] = useState('');
  const { signup, isLoading, error, clearError } = useAuth();

  // Handle form input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    // Check for password mismatch error
    if (name === 'password' || name === 'confirmPassword') {
      if (formData.password && formData.confirmPassword && formData.password !== formData.confirmPassword) {
        setPasswordError('Passwords do not match');
      } else {
        setPasswordError('');
      }
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.password !== formData.confirmPassword) {
      setPasswordError('Passwords do not match');
      return;
    }

    const { password, confirmPassword, ...rest } = formData;
    const userData = { ...rest, role: formData.role };

    // Call signup function from the context (assumed to be an async function)
    await signup(userData, formData.password);
  };

  return (
    <div className="auth-container">
      <div className="auth-card fade-in" style={{ width: '500px', maxWidth: '95%' }}>
        <div className="auth-header">
          <div className="logo d-flex justify-center align-center mb-2">
            <h1 className="ml-1">Chippa Jal</h1>
          </div>
          <p>Create a new account</p>
        </div>

        <form onSubmit={handleSubmit} className="auth-body">
          {error && (
            <div
              className="card bg-light p-2 mb-3"
              style={{ backgroundColor: '#FEECEC', color: 'var(--danger-color)' }}
            >
              <div className="d-flex align-center">
                <p className="mb-0">{error}</p>
                <button
                  type="button"
                  onClick={clearError}
                  style={{
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    marginLeft: 'auto',
                    color: 'var(--danger-color)',
                  }}
                >
                  ×
                </button>
              </div>
            </div>
          )}

          <div className="row">
            <div className="col">
              <div className="form-group">
                <label htmlFor="name" className="form-label">Full Name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  className="form-control"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="col">
              <div className="form-group">
                <label htmlFor="email" className="form-label">Email Address</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  className="form-control"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col">
              <div className="form-group">
                <label htmlFor="password" className="form-label">Password</label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  className="form-control"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="col">
              <div className="form-group">
                <label htmlFor="confirmPassword" className="form-label">Confirm Password</label>
                <input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  className="form-control"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                />
                {passwordError && (
                  <p className="text-danger" style={{ fontSize: '0.85rem', marginTop: '0.25rem' }}>
                    {passwordError}
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="role" className="form-label">Account Type</label>
            <select
              id="role"
              name="role"
              className="form-control"
              value={formData.role}
              onChange={handleChange}
            >
              <option value="customer">Customer</option>
              <option value="owner">Owner</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="contactNumber" className="form-label">Contact Number</label>
            <input
              type="tel"
              id="contactNumber"
              name="contactNumber"
              className="form-control"
              value={formData.contactNumber}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label htmlFor="address" className="form-label">Address</label>
            <input
              type="text"
              id="address"
              name="address"
              className="form-control"
              value={formData.address}
              onChange={handleChange}
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary w-100"
            disabled={isLoading || !!passwordError}
          >
            {isLoading ? 'Creating Account...' : (
              <>
                <UserPlusIcon size={16} className="mr-1" />
                Sign Up
              </>
            )}
          </button>
        </form>

        <div className="auth-footer">
          <p>Already have an account? <Link to="/login">Sign in</Link></p>
        </div>
      </div>
    </div>
  );
};

export default Signup;
