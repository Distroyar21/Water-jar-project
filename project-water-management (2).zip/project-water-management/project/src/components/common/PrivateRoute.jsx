import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const PrivateRoute = ({ children, allowedRoles }) => {
  const { currentUser } = useAuth();

  if (!currentUser) {
    // Redirect to login if not authenticated
    return <Navigate to="/login" />;
  }

  if (!allowedRoles.includes(currentUser.role)) {
    // Redirect to appropriate dashboard if user doesn't have permission
    return <Navigate to={currentUser.role === 'owner' ? '/owner-dashboard' : '/customer-dashboard'} />;
  }

  return <>{children}</>;
};

export default PrivateRoute;
