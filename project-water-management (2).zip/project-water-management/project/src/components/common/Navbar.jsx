import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { DropletIcon, LogOutIcon, UserIcon } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const Navbar = () => {
  const { currentUser, logout, loading } = useAuth(); // Assuming 'loading' is available in your AuthContext
  const navigate = useNavigate();

  const handleLogout = () => {
    logout(); // Ensure logout handles clearing all user-related data, tokens, etc.
    navigate('/login');
  };

  if (loading) {
    return <div>Loading...</div>; // Optional: Add loading spinner or something until the user data is ready
  }

  if (!currentUser) return null; // If there's no user, don't render the navbar

  return (
    <nav className="navbar">
      <div className="container navbar-container">
        <Link to={currentUser.role === 'owner' ? '/owner-dashboard' : '/customer-dashboard'} className="logo">
          <DropletIcon size={24} />
          <span>WaterJar</span>
        </Link>

        <div className="nav-links">
          {currentUser.role === 'customer' && (
            <Link to="/customer-dashboard" className="nav-link">
              Dashboard
            </Link>
          )}

          {currentUser.role === 'owner' && (
            <Link to="/owner-dashboard" className="nav-link">
              Dashboard
            </Link>
          )}

          <div className="d-flex align-center gap-1">
            <span className="nav-link">
              <UserIcon size={16} className="mr-1" />
              {currentUser.name}
            </span>
            <button
              onClick={handleLogout}
              className="btn btn-outline btn-sm"
              aria-label="Logout"
            >
              <LogOutIcon size={16} className="mr-1" />
              Logout
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
