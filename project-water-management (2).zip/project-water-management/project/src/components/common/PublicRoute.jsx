import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const PublicRoute = ({ children }) => {
  const { currentUser } = useAuth();

  if (currentUser) {
    // Redirect to appropriate dashboard based on user role
    return <Navigate to={currentUser.role === 'owner' ? '/owner-dashboard' : '/customer-dashboard'} />;
  }

  return <>{children}</>;
};

export default PublicRoute;
