import React, { useState, useEffect } from 'react';
import Navbar from '../common/Navbar';
import { DropletIcon, DollarSignIcon, CalendarIcon } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { getJarTransactions } from '../../data/mockData';

const CustomerDashboard = () => {
  const { currentUser } = useAuth();
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTransactions = async () => {
      if (currentUser) {
        const data = await getJarTransactions(currentUser.id);
        setTransactions(data);
        setLoading(false);
      }
    };

    fetchTransactions();
  }, [currentUser]);

  const calculateTotalJars = () => {
    return transactions.reduce((total, transaction) => {
      return total + (transaction.jarsTaken - transaction.jarsReturned);
    }, 0);
  };

  const calculateTotalDue = () => {
    return transactions.reduce((total, transaction) => {
      const transactionAmount = transaction.jarsTaken * transaction.pricePerJar;
      return transaction.isPaid ? total : total + transactionAmount;
    }, 0);
  };

  if (!currentUser) return null;

  return (
    <div>
      <Navbar />

      <div className="container mt-4">
        <div className="d-flex justify-between align-center mb-4">
          <h1>Welcome, {currentUser.name}</h1>
        </div>

        <div className="row mb-4">
          <div className="col">
            <div className="card">
              <div className="card-body d-flex align-center">
                <div className="d-flex align-center justify-center p-3" 
                      style={{ 
                        background: 'var(--secondary-color)', 
                        borderRadius: '50%',
                        width: '60px',
                        height: '60px'
                      }}>
                  <DropletIcon size={28} color="var(--primary-color)" />
                </div>
                <div className="ml-3">
                  <h4 className="mb-1">Current Jars</h4>
                  <h2 className="text-primary">{calculateTotalJars()}</h2>
                </div>
              </div>
            </div>
          </div>

          <div className="col">
            <div className="card">
              <div className="card-body d-flex align-center">
                <div className="d-flex align-center justify-center p-3" 
                      style={{ 
                        background: 'var(--secondary-color)', 
                        borderRadius: '50%',
                        width: '60px',
                        height: '60px'
                      }}>
                  <DollarSignIcon size={28} color="var(--primary-color)" />
                </div>
                <div className="ml-3">
                  <h4 className="mb-1">Total Outstanding</h4>
                  <h2 className="text-primary">Rs{calculateTotalDue().toFixed(2)}</h2>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="card mb-4">
          <div className="card-header d-flex justify-between align-center">
            <h3 className="mb-0">Transaction History</h3>
          </div>

          <div className="card-body">
            {loading ? (
              <p>Loading transactions...</p>
            ) : transactions.length === 0 ? (
              <p>No transactions found.</p>
            ) : (
              <div className="table-responsive">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Jars Taken</th>
                      <th>Jars Returned</th>
                      <th>Price per Jar</th>
                      <th>Total</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map(transaction => (
                      <tr key={transaction.id}>
                        <td>{new Date(transaction.date).toLocaleDateString()}</td>
                        <td>{transaction.jarsTaken}</td>
                        <td>{transaction.jarsReturned}</td>
                        <td>Rs{transaction.pricePerJar.toFixed(2)}</td>
                        <td>Rs{(transaction.jarsTaken * transaction.pricePerJar).toFixed(2)}</td>
                        <td>
                          <span className={`p-1 ${transaction.isPaid ? 'text-success' : 'text-danger'}`}
                                style={{ 
                                  borderRadius: '4px',
                                  backgroundColor: transaction.isPaid ? 'rgba(46, 204, 113, 0.1)' : 'rgba(231, 76, 60, 0.1)',
                                  padding: '4px 8px'
                                }}>
                            {transaction.isPaid ? 'Paid' : 'Unpaid'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="mb-0">Your Information</h3>
          </div>

          <div className="card-body">
            <div className="row">
              <div className="col">
                <p><strong>Name:</strong> {currentUser.name}</p>
                <p><strong>Email:</strong> {currentUser.email}</p>
              </div>

              <div className="col">
                <p><strong>Contact Number:</strong> {currentUser.contactNumber || 'Not provided'}</p>
                <p><strong>Address:</strong> {currentUser.address || 'Not provided'}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerDashboard;
