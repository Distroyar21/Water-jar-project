// Mock Users data
export const mockUsers = [
  {
    id: 'owner1',
    name: 'Vedant Rathod',
    email: 'vedantrathod@gmail.com',
    role: 'owner',
    contactNumber: '1234567890',
    address: 'Solapur'
  },
  {
    id: 'cust1',
    name: 'Yash',
    email: 'yash@gmail.com',
    role: 'customer',
    contactNumber: '2648920194',
    address: 'jule solapur'
  },
  {
    id: 'cust2',
    name: 'Shubham',
    email: 'shubham@gmail.com',
    role: 'customer',
    contactNumber: '5478273548',
    address: 'jule solapur'
  },
  {
    id: 'cust3',
    name: 'Shreyash',
    email: 'shreyash@gmail.com',
    role: 'customer',
    contactNumber: '6528191551',
    address: 'Solapur'
  },
  {
    id: 'cust4',
    name: 'Kedar',
    email: 'kedar@gmail.com',
    role: 'customer',
    contactNumber: '7281639405',
    address: 'Jule Solapur'
  }
];

// Mock Transactions data
const mockTransactions = [
  {
    id: 'trans1',
    customerId: 'cust1',
    date: '2025-04-01T10:00:00Z',
    jarsTaken: 2,
    jarsReturned: 0,
    pricePerJar: 20.0,
    isPaid: false
  },
  {
    id: 'trans2',
    customerId: 'cust1',
    date: '2025-03-25T11:30:00Z',
    jarsTaken: 3,
    jarsReturned: 2,
    pricePerJar: 20.0,
    isPaid: true
  },
  {
    id: 'trans3',
    customerId: 'cust2',
    date: '2025-04-02T09:15:00Z',
    jarsTaken: 4,
    jarsReturned: 3,
    pricePerJar: 20.0,
    isPaid: false
  },
  {
    id: 'trans4',
    customerId: 'cust2',
    date: '2025-03-28T14:45:00Z',
    jarsTaken: 2,
    jarsReturned: 2,
    pricePerJar: 20.0,
    isPaid: true
  },
  {
    id: 'trans5',
    customerId: 'cust3',
    date: '2025-04-03T16:20:00Z',
    jarsTaken: 5,
    jarsReturned: 4,
    pricePerJar: 20.0,
    isPaid: false
  },
  {
    id: 'trans6',
    customerId: 'cust4',
    date: '2025-04-01T13:10:00Z',
    jarsTaken: 3,
    jarsReturned: 1,
    pricePerJar: 20.0,
    isPaid: true
  }
];

// Helper functions for data access

// Get all customers
export const getAllCustomers = async () => {
  await new Promise(resolve => setTimeout(resolve, 500));
  return mockUsers.filter(user => user.role === 'customer');
};

// Get customer by ID
export const getCustomerById = async (id) => {
  await new Promise(resolve => setTimeout(resolve, 300));
  const customer = mockUsers.find(user => user.id === id && user.role === 'customer');
  return customer || null;
};

// Get jar transactions for a customer
export const getJarTransactions = async (customerId) => {
  await new Promise(resolve => setTimeout(resolve, 700));
  return mockTransactions
    .filter(transaction => transaction.customerId === customerId)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

// Add a new jar transaction
export const addJarTransaction = async (data) => {
  await new Promise(resolve => setTimeout(resolve, 800));
  
  const newTransaction = {
    id: `trans_${Date.now()}`,
    customerId: data.customerId,
    date: new Date().toISOString(),
    jarsTaken: data.jarsTaken,
    jarsReturned: data.jarsReturned,
    pricePerJar: data.pricePerJar,
    isPaid: false
  };

  mockTransactions.unshift(newTransaction);

  return newTransaction;
};

// Update a jar transaction
export const updateJarTransaction = async (transactionId, updates) => {
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const index = mockTransactions.findIndex(t => t.id === transactionId);
  
  if (index === -1) {
    throw new Error('Transaction not found');
  }

  mockTransactions[index] = {
    ...mockTransactions[index],
    ...updates
  };

  return mockTransactions[index];
};

// Get customer jar stats
export const getCustomerJarStats = async (customerId) => {
  await new Promise(resolve => setTimeout(resolve, 600));

  const customerTransactions = mockTransactions.filter(t => t.customerId === customerId);

  const currentJars = customerTransactions.reduce((total, transaction) => {
    return total + (transaction.jarsTaken - transaction.jarsReturned);
  }, 0);

  const totalDue = customerTransactions.reduce((total, transaction) => {
    const transactionAmount = transaction.jarsTaken * transaction.pricePerJar;
    return transaction.isPaid ? total : total + transactionAmount;
  }, 0);

  return {
    currentJars,
    totalDue
  };
};
