import React, { createContext, useState, useEffect, useContext } from 'react';
import { mockUsers } from '../data/mockData';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null); // Added this line to define currentUser
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email, password) => {
    setIsLoading(true);
    setError(null);
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));

      const user = mockUsers.find((u) => u.email === email);

      if (!user) {
        throw new Error('Invalid email or password');
      }

      setCurrentUser(user);
      localStorage.setItem('currentUser', JSON.stringify(user));
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (userData, password) => {
    setIsLoading(true);
    try {
      console.log('Signing up user..', userData, password);

      await new Promise((resolve) => setTimeout(resolve, 1000));

      const existingUser = mockUsers.find((u) => u.email === userData.email);

      if (existingUser) {
        throw new Error('Email already in use');
      }

      const newUser = {
        id: `user_${Date.now()}`,
        name: userData.name || '',
        email: userData.email || '',
        role: userData.role || 'customer',
        contactNumber: userData.contactNumber,
        address: userData.address,
      };

      mockUsers.push(newUser);

      setCurrentUser(newUser);
      localStorage.setItem('currentUser', JSON.stringify(newUser));

    } catch (err) {
      console.error('Signup error:', err);
      setError(err.message || 'Signup failed');
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
  };

  const clearError = () => {
    setError('');
  };

  const value = {
    currentUser,
    isLoading,
    error,
    login,
    signup,
    logout,
    clearError,
  };

  return (
    <AuthContext.Provider value={value}> {/* Provided value includes currentUser */}
      {children}
    </AuthContext.Provider>
  );
};
