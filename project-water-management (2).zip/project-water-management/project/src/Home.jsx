import React from 'react';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const navigate = useNavigate();

  const handleSignup = (e) => {
    e.preventDefault(); // Prevent default behavior
    navigate('/signup'); // Programmatic navigation
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(to bottom, #f0fff4, #ebf8ff)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      padding: '1rem',
      position: 'relative'
    }}>
      {/* Sign Up Button - Top Right Corner */}
      <button 
        style={{
          position: 'absolute',
          top: '1.5rem',
          right: '1.5rem',
          background: '#2563eb',
          color: 'white',
          fontWeight: 'bold',
          padding: '0.75rem 2rem',
          borderRadius: '9999px',
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
          transition: 'all 0.2s',
          border: 'none',
          cursor: 'pointer',
          zIndex: 10 // Ensure button stays above other elements
        }}
        onMouseOver={(e) => e.currentTarget.style.background = '#1d4ed8'}
        onMouseOut={(e) => e.currentTarget.style.background = '#2563eb'}
        onClick={handleSignup}
      >
        Sign Up
      </button>

      {/* Main Content */}
      <div style={{
        width: '100%',
        maxWidth: '56rem',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        marginTop: '4rem'
      }}>
        {/* Title with gradient text */}
        <h1 style={{
          fontSize: '4.5rem',
          fontWeight: '800',
          marginBottom: '3rem',
          textAlign: 'center',
          background: 'linear-gradient(to right, #16a34a, #2563eb, #000000)',
          WebkitBackgroundClip: 'text',
          backgroundClip: 'text',
          color: 'transparent'
        }}>
          Chippa Jal
        </h1>

        {/* Image with stylish frame */}
        <div style={{ position: 'relative', textAlign: 'center' }}>
          <div style={{
            position: 'absolute',
            inset: '-0.5rem',
            background: 'linear-gradient(to right, #4ade80, #60a5fa)',
            borderRadius: '1rem',
            opacity: '0.75',
            filter: 'blur(8px)',
            transition: 'opacity 0.2s'
          }}></div>
          <img 
            src="./jar.jpg" 
            alt="Chippa Jar"
            style={{
              position: 'relative',
              borderRadius: '0.75rem',
              border: '4px solid #000000',
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
              width: '16rem',
              height: '16rem',
              objectFit: 'cover',
              transition: 'transform 0.3s'
            }}
          />
          <h2 style={{
            color: 'black',
            fontSize: '3.4rem',
            fontWeight: 'bold',
            animation: 'fadeInOut 2s infinite',
            opacity: 0,
            marginTop: '1rem'
          }}>
            जल है तो कल है
          </h2>
        </div>
      </div>
      
      <style>
        {`
          @keyframes fadeInOut {
            0% { opacity: 0; }
            50% { opacity: 1; }
            100% { opacity: 0; }
          }
        `}
      </style>
    </div>
  );
};

export default Home;