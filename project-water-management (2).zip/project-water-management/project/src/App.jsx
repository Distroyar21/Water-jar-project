import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import PublicRoute from './components/common/PublicRoute';
import PrivateRoute from './components/common/PrivateRoute';
import Login from './components/auth/Login';
import Signup from './components/auth/Signup';
import Home from './Home';
import CustomerDashboard from './components/customer/CustomerDashboard';
import OwnerDashboard from './components/owner/OwnerDashboard';
import CustomerDetail from './components/owner/CustomerDetail';
import './index.css';

function App() {
  return (
    <AuthProvider> {/* Wrap everything inside AuthProvider */}
      <Router>
        <Routes>

          {/* Public routes */}
          <Route path="/" element={<Home />} />
          <Route path="/login" element={
            <PublicRoute>
              <Login />
            </PublicRoute>
          } />
          <Route path="/signup" element={
            <PublicRoute>
              <Signup />
            </PublicRoute>
          } />

          {/* Private (Protected) routes */}
          <Route path="/customer/dashboard" element={
            <PrivateRoute allowedRoles={['customer']}>
              <CustomerDashboard />
            </PrivateRoute>
          } />
          <Route path="/owner/dashboard" element={
            <PrivateRoute allowedRoles={['admin']}>
              <OwnerDashboard />
            </PrivateRoute>
          } />
          <Route path="/owner/customer/:id" element={
            <PrivateRoute allowedRoles={['admin']}>
              <CustomerDetail />
            </PrivateRoute>
          } />

          {/* Redirect any unknown routes to Home */}
          <Route path="*" element={<Navigate to="/" />} />

        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
